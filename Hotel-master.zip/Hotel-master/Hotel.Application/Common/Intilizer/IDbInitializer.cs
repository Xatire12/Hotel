﻿namespace Hotel.Application.Common.Intilizer
{
    public interface IDbInitializer
    {
        void Initialize();
    }
}
