﻿namespace Hotel.Application.Common.DTO
{
    public class PieChartDTO
    {
        public decimal[] Series { get; set; }
        public string[] Labels { get; set; }
    }
}
