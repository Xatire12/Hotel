﻿using Hotel.Domain.Entities;

namespace Hotel.Application.Common.InterFaces
{
    public interface IAppUserRepository : IRepository<ApplicationUser>
    {


    }
}
